# DocuGod — Vercel Pack (Final placeholders)

Deploy: push to GitHub, import in Vercel as Other/Static, Deploy.
Replace links in pricing.html, drop teaser in assets/demo.mp4.
